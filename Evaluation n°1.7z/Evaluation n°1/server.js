
const express = require('express');
const app = express();
const mongoose=require("mongoose");

const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));

app.set('views', './views');
app.set('view engine', 'ejs');


app.use(express.static(__dirname + '/public'));

console.log(mongoose.version);

let db=mongoose.connect("mongodb://localhost/bodega",{useNewUrlParser: true, useUnifiedTopology: true });


mongoose.connection.on("error",function(){
    console.log("Erreur de connexion à la base de données");
})
mongoose.connection.on("open",function(){
    console.log("Connexion réussie");
})

let platSchema = mongoose.Schema({
	nom:String,
	description:String,
	categorie:String,
    publie:Boolean,
    image:String,
    prix:Number,
	vedette:Number
});

let Plat = mongoose.model("Plat",platSchema);


app.get('/', (req, res)=>{
	res.render('index');
});

app.get('/login', (req, res)=>{
	res.render('login');
});

app.get('/carte', (req, res)=>{
    Plat.find({publie:true}).sort('mise_en_avant').exec(function(err,plats){
        if(err)throw err;
        console.log(plats);
        res.render('carte',{plats:plats});
    })
})

app.get('/carte/:categorie',function(req,res){
    let name= req.params.categorie;
Plat.find({categorie:name},function(err,recette){
         if(err) throw err
         res.render('carte',{recette:recette});
})
})

app.get('/admin',function(req,res){
    res.render('admin')
})

app.post('/admin', function(req,res){ 
    let nom = req.body.nom; 
    let description =req.body.description; 
    let prix = req.body.prix; 
    let categorie = req.body.categorie;

    let newPlats = Plat({ 
        "nom": nom, 
        "description":description, 
        "prix":prix,
        "categorie":categorie,
    }) 
    newPlats.save();
    console.log(Plat)

    return res.redirect('/');
})

app.get('/liste',function(req,res){
    res.render('liste')
})

app.use(function(req,res){
    res.setHeader('Content-Type','text/plain');
    res.status(404).send('Page introuvable');
})


app.listen(3000);
